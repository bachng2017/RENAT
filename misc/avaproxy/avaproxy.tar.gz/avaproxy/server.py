#! /usr/bin/env python
# -*- coding:utf-8 -*-
import os,time,sys,getopt
import shutil,logging
from logging import getLogger, StreamHandler, Formatter, FileHandler
from ava_server import AvaServer

# logging setting
logger = getLogger("AvaProxyServer")
logger.setLevel(logging.INFO)
stream_handler = StreamHandler()
stream_handler.setLevel(logging.INFO)
handler_format = Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler = FileHandler('server.log', 'a')
stream_handler.setFormatter(handler_format)
file_handler.setFormatter(handler_format)
logger.addHandler(stream_handler)
logger.addHandler(file_handler)

def usage():
    print('avaproxyserve v0.0.1')
    print('usage: %s [-h|--help] [-s ip|--server=ip] [-p port|--port=port]' % sys.argv[0])
    print('default setting: -s 0.0.0.0 -p 5001')
    print('press Ctrl-C to quit')
    exit(1)

PORT = 5001
SERVER = '0.0.0.0'
if __name__ == '__main__':
    options, remainder = getopt.getopt(sys.argv[1:], 'hs:p:', ['help','server=', 'port='])
    for opt, arg in options:
        if opt in ('-h', '--help'): usage()
        elif opt in ('-p','--port'):
            PORT = int(arg)
        elif opt in ('-s','--server'):
            SERVER = arg
   
server = AvaServer(SERVER,PORT)

@server.api('ava::login/<user>')
def login(user):
    """ Connects to a AVA server
    
        Parameters:
        - user: user name
    """
    logger.info('login with username=%s' % user)
    result = server.ava.login(user,tempworkspace=True)

    tmp_dir = '%s/tmp/%s/tmp.%s' % (os.getcwd(),user,result)
    if not os.path.exists(tmp_dir): os.makedirs(tmp_dir)
    server.tmp_dir = tmp_dir

    return result

@server.api('ava::reserve_all_ports')
def reserve_all_ports():
    """ Reserves all ports
    """
    logger.info('reserves all ports')
    server.ava.reserveAll()
    result = 'ava::ok'
    return result 


@server.api('ava::release_all_ports')
def release_all_ports():
    """ Releases all ports
    """
    logger.info('release all ports')
    server.ava.releaseAll()
    result = 'ava::ok'
    return result 


@server.api('ava::logout')
def logout():
    """ Disconnects from a server and terminate current session
    """
    # release all ports
    logger.info('release all ports')
    server.ava.releaseAll()

    # logout 
    server.ava.logout()

    # cleanup
    logger.info('clean up')
    if os.path.exists(server.tmp_dir): shutil.rmtree(server.tmp_dir)
    return 'ava::ok'


@server.api('ava::connect/<host>')
def connect(host):
    """ Connects to a AVA server
        
        Parameters:
        - host: IP address of the server
    """ 
    result = server.ava.connect(host)
    server.sessionid = result
    return result


@server.api('ava::get_user')
def get_user():
    return server.ava.get('system1','user')


@server.api('ava::send_file/<size>/<file_path>')
def send_file(size,file_path):
    """ Receives a file from the remote client
        
        Parameters:
        - size: is the file size 
        - file_path: is the absolute path of the receive file. The 'slash' must
          be doubled. Eg: ``//tmp//test.txt``

    Returns the realsize of the saved file (should be equal to `size`)

    *Notes*: file will be overwritten if it is already exits
    """
    result = 0
    current_size = 0
    file_size = int(size)
    server.clientsock.send('ava::ok')
    logger.info('receiving file `%s` with size %s' % (file_path,size))
    f = open(server.tmp_dir + '/' + file_path,'wb')
    while current_size < file_size:
        data = server.clientsock.recv(1024)
        if not data: break
        if len(data) + current_size > file_size:
            data=data[:file_size - current_size]
        f.write(data)
        current_size += len(data) 
        # logger.info('current size is %d' % current_size)
        # sys.stdout.write('.')
        # sys.stdout.flush()
    logger.info('')
    f.close()
    logger.info('received file %s with size %s' % (file_path,current_size))
    return str(current_size)


@server.api('ava::load_config/<config_path>')
def load_config(config_path):
    """ Loads a spf AVA config from `src_path` to `dst_path`

    Assuming that the `config_path` has been on the server
    """
    spf_path = server.tmp_dir + '/' + config_path 
    project_handle = server.ava.perform('import','system1',spffile=spf_path)
    logger.info('project_handle = %s' %  project_handle)
    
    server.test_handle = server.ava.get(project_handle,'tests')
    logger.info('test_hanlde = %s' % server.test_handle)
    return server.test_handle


@server.api('ava::start_test/<trial>')
def start_test(trial):
    """ Starts the test
    """
    response = server.ava.apply(server.test_handle,trial=trial)
    logger.info('response = %s' % response)
    return response


@server.api('ava::wait_until_finish/<timeout>')
def wait_until_finish(timeout):
    """ Waits until the test `ID` finished
    """
    count = 0
    interval = 5
    info = server.ava.get('system1','runningtestinfo')
    status = "TEST_UNKNOWN"

    # 
    while count < int(timeout) and status != "TEST_COMPLETED":
        # sys.stdout.write('.')
        # sys.stdout.flush()
        status = server.ava.get(info,'runningTestStatus')
        logger.info('status = %s' % status)
        time.sleep(interval)
        count += interval 

    # if status != 'TEST_COMPLETED':
    #     result = 'ava::error/%s' % status
    # else:
    #    result = 'ava::ok'
    result = server.ava.get(info,'testError')
    if result == '':
        result = 'ava::ok'

    return result


@server.api('ava::get_test_result')
def get_test_result():
    """ Returns the test result path
    """
    info = server.ava.get('system1','lastfinishedtestinfo')
    logger.info('info = %s' % info)
    result_path = server.ava.get(info,'testResultsDir')
    logger.info('test result path = %s' % result_path)
    ### copy to tmp folder
    dst_path = server.tmp_dir + '/' + 'results'
    logger.info('copy results to `%s' % dst_path)
    if result_path != '':
        if os.path.exists(dst_path):
            os.rmdir(dst_path)
        shutil.copytree(result_path,dst_path)

    cwd_path_len = len(dst_path)
    
    for cur_dir,dirs,files in os.walk(dst_path):
        logger.info('current dir %s' % cur_dir)
        for item in dirs:
            dir_path = ('%s/%s' % (cur_dir[cwd_path_len:],item)).replace('/','//')
            logger.info('send dir %s' % dir_path)
            server.clientsock.send('ava::dir/%s' % dir_path)
            response = server.clientsock.recv(1024)

        for item in files:
            file_path = ('%s/%s' % (cur_dir,item)).replace('./','//')
            send_file = ('%s/%s' % (cur_dir[cwd_path_len:],item)).replace('./','//')
            logger.info('send file %s' % file_path)
            file_size = str(os.path.getsize(file_path))
            server.clientsock.send('ava::file/%s/%s' % (file_size,send_file))
            response = server.clientsock.recv(1024)
            if response == 'ava::ok':
                with open(file_path,'re') as f:
                    data = f.read(1024)
                    while data:
                        server.clientsock.send(data)
                        data = f.read(1024)
            response = server.clientsock.recv(1024)

    server.clientsock.send('ava::ok')  
    return result_path


@server.api('ava::get_file/<file_path>')
def get_file(file_path):
    """ Get a file from remote site
    """
    file_size = str(os.path.getsize(file_path))
    server.clientsock.send('ava::file/%s' % file_size)
    response = server.clientsock.recv(1024)
    if response == 'ava::ok':
        with open(file_path,'re') as f:
            data = f.read(1024)
            while data:
                server.clientsock.send(data)
                data = f.read(1024)
    
    logger.info('sent file `%s` with size `%s`' % (file_path,file_size))
    return 'ava::ok'


@server.api('ava::get_test_dir')
def get_test_dir():
    """ Get the current test dir
    """
    response = server.tmp_dir
    return response

@server.api('ava::add_license_server/<server_ip>')
def add_license_server(server_ip):
    """ Adds license server
    """
    license_server = server.ava.get('licenseservermanager1','server')
    response = 'ava::ok'
    if license_server != server_ip:
        response = server.ava.perform('createLicenseServer','licenseservermanager1',server=server_ip)
    logger.info('current license server: %s' % license_server)
    return response

@server.api('ava::reserve_port/<intf>/<ip>/<card>/<port>')
def reserve_port(intf,ip,card,port):
    """ Reserver a port
    """
    res = server.ava.connect(ip)
    logger.info('connected to chassis `%s` with result `%s`' % (ip,res))

    # find the interface
    interface_list = []
    for config in server.ava.get(server.test_handle,'configuration').split():
        for topology in server.ava.get(config,'topology').split():
            for item in server.ava.get(topology,'interface').split():
                interface_list.append(item)
    interface = interface_list[int(intf)]
    # find physical port
    location = '%s/%s/%s' % (ip,card,port)
    logger.info('reserving port for interface `%s` by `%s`' % (interface,location))
    for chassis in server.ava.get("system1.physicalchassismanager", "physicalchassis").split():
        for module in server.ava.get(chassis, "physicaltestmodules").split():
            for p in server.ava.get(module, "ports").split():
                if server.ava.get(p, "location") == location:
                    # We found the port. Now map and reserve it.
                    physif = server.ava.get(p, "physIf")
                    ids    = server.ava.get(p, "locationDisplayString")
                    ils    = server.ava.get(p, "locationString")    
                    server.ava.perform(  "SetInterfaceAttributes", interface, port=location, 
                                        physIf=physif, interfaceDisplayString=ids, interfaceLocationString=ils)
                    server.ava.perform("ReservePort", "system1", portaddress=location, force="force")
    
    logger.info('reserved port `%s/%s/%s` with result `%s`' % (ip,card,port,res))
    return res 
    
### main program
if __name__ == '__main__':
    logger.info('current folder %s' % os.getcwd())
    server.run()



