# -*- coding:utf-8 -*-
import socket,re
from Tkinter import TclError
from avalancheapi import avalanche
from decorator import decorator
from logging import getLogger, StreamHandler, Formatter

""" A simple class that provide server side function for TestCenter application

"""
class AvaServer():
    def __init__(self,host=None,port=None):
        self.tmp_dir = ''
        self.cmd_list = {}
        self.var_list = {}
        self.match_list = {}
        self.logger = getLogger("AvaProxyServer")
        self.test_handle = None
        self.sessionid = None

        if host is None: 
            self.host = "0.0.0.0"
        else:
            self.host = host
        if port is None:
            self.port = 5001
        else:
            self.port = port
        self.ava = avalanche.AVA(apipath='/opt/spirent/api/Layer_4_7_Application_Linux/TclAPI/')
        self.serversock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.serversock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.clientsock = None
        self.client_address = None
    

    def start_data_mode():
        self.data_mode = True
        self.buffer = b''

    

    def stop_data_mode():
        self.data_mode = False


    def api(self,route):
        def _api(f,*args,**kwargs):
            def wrapper(*args,**kwargs):
                self.logger.info('processing command: `%s`' % key)
                return f(*args,**kwargs)
            key = re.sub('(/*?)<(.*?)>(/*?)','',route) 
            vars = re.findall(r'<(.*?)>',route)
            match = re.sub('<(.*?)>','(.*?[^/])',route)+'$'
            self.cmd_list[key] = wrapper
            self.var_list[key] = vars
            self.match_list[key] = match
            self.logger.info('register key %s->%s' % (key,match))
            return wrapper
        return _api

    def cmd_num(self):
        return len(self.cmd_list)

    def run(self):
        self.logger.info('listen at `%s:%d`' % (self.host,self.port))
        self.serversock.bind((self.host,self.port))
        self.serversock.listen(10)
        self.logger.info('number of registered commands = %d' % self.cmd_num())
        keep_running = True
        while keep_running:
            try:
                self.logger.info("Waiting for connections...")
                self.clientsock, self.client_address = self.serversock.accept()
                rcv_msg = ''
                result = None
                while True:
                    try:
                        rcv_msg = self.clientsock.recv(1024)
                        # a empty msg might be a sign that client has closed the
                        # socket
                        if rcv_msg == '': break
                        self.logger.info('=================')
                        self.logger.info('received msg = `%s`' % rcv_msg)
                        result = "ava::unknown"

                        found_cmd = None
                        value = None
                        # search the registered commands
                        for key in self.match_list:
                            m=re.match(self.match_list[key],rcv_msg)
                            if m:
                                found_cmd = key
                                value = m.groups() 
                                break 
                        if found_cmd:
                            self.logger.info('found cmd key `%s`. Creating parameters ...' % key)
                            kwargs = {}
                            for i,j in zip(self.var_list[key],value):
                                self.logger.info('    %s->%s' % (i,j))
                                kwargs[i]=j
                           
                            # execute the registered command 
                            result=self.cmd_list[found_cmd](**kwargs) 
                            self.logger.info('result = %s' % result)
                        else:
                            self.logger.info('unknown command')    
                    except TclError as err:
                        self.logger.info('An TclError exception occured')
                        self.logger.info(err)
                        result = err
                    finally:
                        self.logger.info('')
                        if result is None:
                            result = "ava::None"
                        self.clientsock.sendall(str(result))
            except socket.error as err:
                self.logger.info('An exception type %s occured' % type(err))
                self.logger.info(err)
                self.logger.info('socket is closed by remote')
                self.clientsock.close() 
            except KeyboardInterrupt:
                if self.clientsock:
                    self.clientsock.close()
                keep_running = False
                self.logger.info('byebye')
                exit(0)
                
 

